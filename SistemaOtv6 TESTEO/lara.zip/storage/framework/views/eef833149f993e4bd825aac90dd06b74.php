<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center text-center mt-3">
            <h2>Órdenes del Técnico</h2>
        </div>

        <div class="table-responsive">
            <table class="table table-striped" id="ot_tabledata">
                <thead>
                    <tr>
                        <th>#Orden</th>
                        <th>Descripción</th>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($orden->numero_ot); ?></td>
                        <td><?php echo e($orden->descripcion_ot); ?></td>
                        <td><?php echo e($orden->contactoOt->contacto->sucursal->cliente->nombre_cliente); ?></td>
                        <td><?php echo e($orden->servicio->nombre_servicio); ?></td>
                        <td><?php echo e($orden->estado->descripcion_estado_ot); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($orden->created_at))); ?></td>
                        <td>
                            <div class="d-flex">
                                <a href="<?php echo e(route('ordenesTecnicos.show', $orden->numero_ot)); ?>" class="btn btn-primary me-1" style="background-color: #cc0066; border-color: #cc0066;">
                                    <i class="fas fa-eye"></i>
                                </a>
                                
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-4">
            <?php if($ordenes->hasPages()): ?>
            <nav>
                <ul class="pagination" style="color: #cc6633;">
                    
                    <?php if($ordenes->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&laquo;</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($ordenes->url(1)); ?>" rel="prev" style="color: #cc6633;">&laquo;</a>
                    </li>
                    <?php endif; ?>

                    
                    <?php if($ordenes->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&lsaquo;</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($ordenes->previousPageUrl()); ?>" rel="prev" style="color: #cc6633;">&lsaquo;</a>
                    </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $ordenes->getUrlRange(max(1, $ordenes->currentPage() - 5), min($ordenes->lastPage(), $ordenes->currentPage() + 5)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $ordenes->currentPage()): ?>
                    <li class="page-item active" aria-current="page">
                        <span class="page-link" style="background-color: #cc6633; border-color: #cc6633;"><?php echo e($page); ?></span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($url); ?>" style="color: #cc6633;"><?php echo e($page); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($ordenes->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($ordenes->nextPageUrl()); ?>" rel="next" style="color: #cc6633;">&rsaquo;</a>
                    </li>
                    <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&rsaquo;</span>
                    </li>
                    <?php endif; ?>

                    
                    <?php if($ordenes->currentPage() == $ordenes->lastPage()): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&raquo;</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($ordenes->url($ordenes->lastPage())); ?>" rel="next" style="color: #cc6633;">&raquo;</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/ordenesTecnicos/ottecnico.blade.php ENDPATH**/ ?>