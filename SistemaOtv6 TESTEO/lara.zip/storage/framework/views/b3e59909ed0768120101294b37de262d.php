<aside class="col-12 col-md-2 p-0 bg-dark flex-shrink-1" style="overflow-x: auto;">
    <nav class="navbar navbar-expand navbar-dark bg-dark flex-md-column flex-row align-items-start py-2" style="width: 250px;">
        <div class="collapse navbar-collapse">
            <ul class="flex-md-column flex-row navbar-nav w-100 justify-content-between" style="max-height: calc(100vh - 60px); overflow-y: auto;">
                <li class="nav-item">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ordenes.index')): ?>
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('ordenes*') ? 'active' : ''); ?>" href="<?php echo e(route('ordenes.index')); ?>">
                        <i class="fas fa-shopping-cart"></i> <span>Órdenes</span>
                    </a>
                    <?php endif; ?>
                </li>

                <!-- Aquí van el resto de los elementos del menú -->
                <li class="nav-item">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.index')): ?>
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('clientes*') ? 'active' : ''); ?>" href="<?php echo e(route('clientes.index')); ?>"><i class="fas fa-user-friends"></i> <span>Clientes</span></a>
                    <?php endif; ?>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('sucursales*') ? 'active' : ''); ?>" href="<?php echo e(route('sucursales.index')); ?>">
                        <i class="fas fa-building"></i> <span>Sucursales</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('contactos*') ? 'active' : ''); ?>" href="<?php echo e(route('contactos.index')); ?>">
                        <i class="fas fa-address-book"></i> <span>Contactos</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('servicios*') ? 'active' : ''); ?>" href="<?php echo e(route('servicios.index')); ?>">
                        <i class="fas fa-concierge-bell"></i> <span>Servicios</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('tareas*') ? 'active' : ''); ?>" href="<?php echo e(route('tareas.index')); ?>">
                        <i class="fas fa-tasks"></i> <span>Tareas</span>
                    </a>
                </li>




                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('convenios*') ? 'active' : ''); ?>" href="#"><i class="fas fa-handshake"></i> <span>Convenios</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('repuestos*') ? 'active' : ''); ?>" href="#"><i class="fas fa-tools"></i> <span>Repuestos</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('tecnicos*') ? 'active' : ''); ?>" href="<?php echo e(route('tecnicos.index')); ?>">
                        <i class="fas fa-user-cog"></i> <span>Técnicos</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('modelos*') ? 'active' : ''); ?>" href="<?php echo e(route('modelos.index')); ?>">
                        <i class="fas fa-desktop"></i> <span>Modelos</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('dispositivos*') ? 'active' : ''); ?>" href="<?php echo e(route('dispositivos.index')); ?>">
                        <i class="fas fa-laptop"></i> <span>Dispositivos</span></a>
                </li>


                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('parametros*') ? 'active' : ''); ?>" href="<?php echo e(route('parametros.index')); ?>">
                        <i class="fas fa-cogs"></i> <span>Parámetros</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('reclamos*') ? 'active' : ''); ?>" href="#"><i class="fas fa-exclamation-triangle"></i> <span>Reclamos</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('seguimiento*') ? 'active' : ''); ?>" href="#"><i class="fas fa-binoculars"></i> <span>Seguimiento</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('agendamiento*') ? 'active' : ''); ?>" href="#"><i class="fas fa-calendar-alt"></i> <span>Agendamiento</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('contrato*') ? 'active' : ''); ?>" href="#"><i class="fas fa-file-contract"></i> <span>Contrato</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('roles*') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                        <i class="fas fa-user-shield"></i> <span>Roles</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-white <?php echo e(Request::is('usuarios*') ? 'active' : ''); ?>" href="<?php echo e(route('usuarios.index')); ?>">
                        <i class="fas fa-users"></i> <span>Usuarios</span>
                    </a>
                </li>


                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <a class="nav-link pl-0 text-white" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i> <span>Salir</span>
                </a>
            </ul>
        </div>
    </nav>
</aside>






<!-- <li class="nav-item dropdown">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.index')): ?>
    <a class="nav-link dropdown-toggle pl-0 text-white <?php echo e(Request::is('clientes*') ? 'active' : ''); ?>" href="#" id="clientesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user-friends"></i> <span>Clientes</span>
    </a>
    <div class="dropdown-menu bg-dark" aria-labelledby="clientesDropdown">
        <a class="dropdown-item text-white" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
        <a class="dropdown-item text-white" href="#">Opción 2</a>
        <a class="dropdown-item text-white" href="#">Opción 3</a>
    </div>
    <?php endif; ?>
</li> --><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/layouts/sidebar/dashboard.blade.php ENDPATH**/ ?>