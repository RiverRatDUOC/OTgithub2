<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main class="col bg-faded py-3 flex-grow-1">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center text-center mt-3">
            <h2>Crear Usuario</h2>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <!-- Mostrar mensajes de error si los hay -->
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('usuarios.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- Campo Nombre de Usuario -->
                    <div class="mb-3">
                        <label for="nombre_usuario" class="form-label">Nombre de Usuario</label>
                        <input type="text" class="form-control" id="nombre_usuario" name="nombre_usuario" value="<?php echo e(old('nombre_usuario')); ?>" required>
                    </div>

                    <!-- Campo Email -->
                    <div class="mb-3">
                        <label for="email_usuario" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email_usuario" name="email_usuario" value="<?php echo e(old('email_usuario')); ?>" required>
                    </div>

                    <!-- Campo Contraseña -->
                    <div class="mb-3">
                        <label for="password_usuario" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="password_usuario" name="password_usuario" required>
                    </div>

                    <!-- Campo Confirmar Contraseña -->
                    <div class="mb-3">
                        <label for="password_usuario_confirmation" class="form-label">Confirmar Contraseña</label>
                        <input type="password" class="form-control" id="password_usuario_confirmation" name="password_usuario_confirmation" required>
                    </div>



                    <!-- Botón de Crear Usuario -->
                    <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Crear Usuario</button>
                    <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/usuarios/crear.blade.php ENDPATH**/ ?>