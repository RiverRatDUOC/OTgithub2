<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<main class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center text-center mt-3">
            <h2>Usuarios</h2>
            <div class="d-flex align-items-center">
                <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-primary ms-auto" style="background-color: #cc6633; border-color: #cc6633;">
                    <i class="bi bi-plus"></i> Agregar
                </a>
            </div>
        </div>

        <form action="<?php echo e(route('usuarios.buscar')); ?>" method="get" class="input-group mt-3">
            <input type="text" name="search" id="search" class="form-control" placeholder="Buscar por nombre, correo, roles...">
            <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Buscar</button>
        </form>

        <!-- Tabla de usuarios -->
        <div class="table-responsive mt-2">
            <table class="table table-bordered table-striped text-center shadow" style="width: 100%;">
                <thead class="table-primary">
                    <tr>
                        <th>#ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Roles</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->nombre_usuario); ?></td> <!-- Cambiado a nombre_usuario -->
                        <td><?php echo e($user->email_usuario); ?></td> <!-- Cambiado a email_usuario -->
                        <td>
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge" style="background-color: <?php echo e($role->color); ?>; color: white;"><?php echo e($role->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td>
                            <div class="d-flex justify-content-center align-items-center">
                                <!-- Botón Editar -->
                                <form action="<?php echo e(route('usuarios.editar', $user->id)); ?>" method="GET" style="margin-right: 10px;">
                                    <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                </form>
                                <!-- Botón Eliminar -->
                                <form action="<?php echo e(route('usuarios.destroy', $user->id)); ?>" method="POST" onsubmit="return confirm('¿Está seguro de eliminar este usuario?')" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" style="background-color: #d9534f; border-color: #d43f3a;">
                                        <i class="fas fa-trash-alt"></i> Eliminar
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-4">
            <?php if($users->hasPages()): ?>
            <nav>
                <ul class="pagination" style="color: #cc6633;">
                    
                    <?php if($users->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&lsaquo;</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev" style="color: #cc6633;">&lsaquo;</a>
                    </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $users->getUrlRange(1, $users->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $users->currentPage()): ?>
                    <li class="page-item active" aria-current="page"><span class="page-link" style="background-color: #cc6633; border-color: #cc6633;"><?php echo e($page); ?></span></li>
                    <?php else: ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>" style="color: #cc6633;"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($users->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next" style="color: #cc6633;">&rsaquo;</a>
                    </li>
                    <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link" style="color: #cc6633;">&rsaquo;</span>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/usuarios/usuarios.blade.php ENDPATH**/ ?>