<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/detalleOrden.css')); ?>">
    <main class="col bg-faded py-3 flex-grow-1">
        <div class="container-fluid">
            <h2 class="text-center mt-3">Detalle de la Orden</h2>
            <div class="card mt-3">
                <div class="card-body">
                    <div class="infoExtra">

                        <?php
                            $prioridadClass = '';

                            switch ($orden->prioridad->id) {
                                case 1:
                                    $prioridadClass = 'prioridadBaja';
                                    break;
                                case 2:
                                    $prioridadClass = 'prioridadMedia';
                                    break;
                                case 3:
                                    $prioridadClass = 'prioridadAlta';
                                    break;
                                default:
                                    $prioridadClass = 'prioridadBaja';
                                    break;
                            }

                            $estadoClass = '';

                            switch ($orden->estado->id) {
                                case 1:
                                    $estadoClass = 'estadoIniciada';
                                    break;
                                case 2:
                                    $estadoClass = 'estadoPendiente';
                                    break;
                                case 3:
                                    $estadoClass = 'estadoFinalizada';
                                    break;
                                default:
                                    $estadoClass = 'estadoPendiente';
                                    break;
                            }
                        ?>
                        <span class="infoEx <?php echo e($prioridadClass); ?>" data-toggle="tooltip" data-placement="top"
                            title="Prioridad de la orden"><?php echo e($orden->prioridad->descripcion_prioridad_ot); ?></span>
                        <span class="infoEx <?php echo e($estadoClass); ?>" data-toggle="tooltip" data-placement="top"
                            title="Estado de la orden"><?php echo e($orden->estado->descripcion_estado_ot); ?></span>
                        <span class="infoEx" data-toggle="tooltip" data-placement="top"
                            title="Tipo de orden"><?php echo e($orden->tipo->descripcion_tipo_ot); ?></span>
                        <span class="infoEx" data-toggle="tooltip" data-placement="top"
                            title="Tipo de visita de la orden"><?php echo e($orden->tipoVisita->descripcion_tipo_visita); ?></span>
                    </div>
                    <h5 class="card-title"><strong>Número Ot #<?php echo e($orden->numero_ot); ?></strong></h5>
                    <p class="card-text"><strong>Nombre del Cliente</strong></p>
                    <?php if(count($orden->contactoOt) != 0): ?>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(html_entity_decode($orden->contactoOt[0]->contacto->sucursal->cliente->nombre_cliente)); ?>"
                            disabled>
                    <?php else: ?>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(html_entity_decode($orden->contacto->sucursal->cliente->nombre_cliente)); ?>" disabled>
                    <?php endif; ?>

                    <p class="card-text"><strong>Sucursal</strong></p>
                    <?php if(count($orden->contactoOt) != 0): ?>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(html_entity_decode($orden->contactoOt[0]->contacto->sucursal->nombre_sucursal)); ?> - <?php echo e(html_entity_decode($orden->contactoOt[0]->contacto->sucursal->direccion_sucursal)); ?>"
                            disabled>
                    <?php else: ?>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(html_entity_decode($orden->contactoOt[0]->contacto->sucursal->nombre_sucursal)); ?> - <?php echo e(html_entity_decode($orden->contactoOt[0]->contacto->sucursal->direccion_sucursal)); ?>"
                            disabled>
                    <?php endif; ?>

                    <p class="card-text"><strong>Contacto(s):</strong></p>
                    <ul>
                        <?php $__currentLoopData = $orden->contactoOt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(html_entity_decode($contacto->contacto->nombre_contacto)); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    


                    
                    
                    <p class="card-text"><strong>Encargado</strong></p>
                    <input type="text" name="" id="" class="form-control inputsText"
                        value="<?php echo e(html_entity_decode($orden->tecnicoEncargado->nombre_tecnico)); ?>" disabled>
                    <!-- Mostrar técnicos participantes -->
                    <?php if($orden->EquipoTecnico): ?>
                        <label for="participantes"><strong>Tecnico(s):</strong></label>
                        <ul>
                            <?php $__currentLoopData = $orden->EquipoTecnico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $EquipoTecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e(html_entity_decode($EquipoTecnico->tecnico->nombre_tecnico)); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p>No hay participantes asociados a esta orden.</p>
                    <?php endif; ?>


                    <p class="card-text"><strong>Servicio</strong> </p>
                    <input type="text" name="" id="" class="form-control inputsText"
                        value="<?php echo e(html_entity_decode($orden->servicio->nombre_servicio)); ?>" disabled>
                    
                    
                    <p class="card-text"><strong>Fecha de creación de orden de trabajo</strong> </p>

                    <input type="text" name="" id="" class="form-control inputsText"
                        value="<?php echo e(date('d-m-Y', strtotime($orden->created_at))); ?>" disabled>

                    <?php if($orden->fecha_inicio_planificada_ot): ?>
                        <p class="card-text"><strong>Fecha de inicio de orden de trabajo</strong></p>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(date('d-m-Y', strtotime($orden->fecha_inicio_planificada_ot))); ?>" disabled>
                    <?php endif; ?>
                    <?php if($orden->fecha_fin_planificada_ot): ?>
                        <p class="card-text"><strong>Fecha estimada de finalización</strong></p>
                        <input type="text" name="" id="" class="form-control inputsText"
                            value="<?php echo e(date('d-m-Y', strtotime($orden->fecha_fin_planificada_ot))); ?>" disabled>
                    <?php endif; ?>
                    <p class="card-text"><strong>Cotización</strong></p>
                    <input type="text" name="" id="" class="form-control inputsText"
                        value=<?php if($orden->cotizacion): ?> "<?php echo e($orden->cotizacion); ?>"
                                <?php else: ?>
                                "No tiene cotización" <?php endif; ?>
                        disabled>

                    <p class="card-text"><strong>Horas</strong></p>
                    <input type="text" name="" id="" class="form-control inputsText"
                        value="<?php echo e($orden->horas_ot); ?>" disabled>

                    <p class="card-text"><strong>Descripción</strong></p>
                    <textarea class="form-control" name="descripcion" id="descripcion" cols="30" rows="5" disabled><?php echo e(html_entity_decode($orden->descripcion_ot)); ?></textarea>
                    
                    <p class="card-text"><strong>Comentario:</strong>
                        <?php if($orden->comentario_ot == null): ?>
                            <textarea class="form-control" name="descripcion" id="descripcion" cols="30" rows="5" disabled>Sin comentarios.</textarea>
                        <?php else: ?>
                            <textarea class="form-control" name="descripcion" id="descripcion" cols="30" rows="5" disabled><?php echo e(html_entity_decode($orden->comentario_ot)); ?></textarea>
                        <?php endif; ?>
                    </p>

                    <?php if($orden->servicio->cod_tipo_servicio == 1): ?>
                        <div class="accordion my-3" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left" type="button"
                                            data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                                            aria-controls="collapseOne">
                                            Tareas
                                        </button>
                                    </h2>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Tarea</th>
                                                    <th scope="col">Tiempo duración (Minutos)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orden->TareasOt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e(html_entity_decode($tarea->tarea->nombre_tarea)); ?></td>
                                                        <td><?php echo e($tarea->tarea->tiempo_tarea); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php else: ?>
                        <?php if(count($orden->DispositivoOT) != 0): ?>
                            <?php $__currentLoopData = $orden->DispositivoOT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="dispositivos">
                                    <p class="card-text"><strong>Dispositivo</strong></p>
                                    <p class="card-text"><strong>Número de serie:</strong>
                                        <?php echo e($dispositivo->dispositivo->numero_serie_dispositivo); ?>

                                    </p>
                                    <p class="card-text"><strong>Modelo:</strong>
                                        <?php echo e($dispositivo->dispositivo->modelo->nombre_modelo); ?>

                                    </p>
                                    <p class="card-text"><strong>Marca:</strong>
                                        <?php echo e($dispositivo->dispositivo->modelo->marca->nombre_marca); ?>

                                    </p>
                                    <div class="accordion my-3" id="accordionExample<?php echo e($loop->iteration); ?>">
                                        <div class="card">
                                            <div class="card-header" id="heading<?php echo e($loop->iteration); ?>">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link btn-block text-left" type="button"
                                                        data-toggle="collapse"
                                                        data-target="#collapse<?php echo e($loop->iteration); ?>"
                                                        aria-expanded="false"
                                                        aria-controls="collapse<?php echo e($loop->iteration); ?>">
                                                        Tareas
                                                    </button>
                                                </h2>
                                            </div>

                                            <div id="collapse<?php echo e($loop->iteration); ?>" class="collapse"
                                                aria-labelledby="heading<?php echo e($loop->iteration); ?>"
                                                data-parent="#accordionExample<?php echo e($loop->iteration); ?>">
                                                <div class="card-body">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Tarea</th>
                                                                <th scope="col">Tiempo duración (Minutos)</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $dispositivo->tareaDispositivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e(html_entity_decode($tarea->tarea->nombre_tarea)); ?>

                                                                    </td>
                                                                    <td><?php echo e($tarea->tarea->tiempo_tarea); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <?php if($dispositivo->detalles): ?>
                                        <div class="accordion my-3" id="accordionExampleD<?php echo e($loop->iteration); ?>">
                                            <div class="card">
                                                <div class="card-header" id="headingD<?php echo e($loop->iteration); ?>">
                                                    <h2 class="mb-0">
                                                        <button class="btn btn-link btn-block text-left" type="button"
                                                            data-toggle="collapse"
                                                            data-target="#collapseD<?php echo e($loop->iteration); ?>"
                                                            aria-expanded="false"
                                                            aria-controls="collapseD<?php echo e($loop->iteration); ?>">
                                                            Detalles
                                                        </button>
                                                    </h2>
                                                </div>

                                                <div id="collapseD<?php echo e($loop->iteration); ?>" class="collapse"
                                                    aria-labelledby="headingD<?php echo e($loop->iteration); ?>"
                                                    data-parent="#accordionExampleD<?php echo e($loop->iteration); ?>">
                                                    <div class="card-body">
                                                        <table class="table table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th scope="col">Detalle</th>
                                                                    <th scope="col">Descripción</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>Rayones</td>
                                                                    <td><?php echo e($dispositivo->detalles->rayones_det); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Rupturas</td>
                                                                    <td><?php echo e($dispositivo->detalles->rupturas_det); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Tornillos</td>
                                                                    <td><?php echo e($dispositivo->detalles->tornillos_det); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Gomas</td>
                                                                    <td><?php echo e($dispositivo->detalles->gomas_det); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Estado del equipo</td>
                                                                    <td><?php echo e($dispositivo->detalles->estado_dispositivo_det); ?>

                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Observaciones adicionales</td>
                                                                    <td><?php echo e($dispositivo->detalles->observaciones_det); ?>

                                                                    </td>
                                                                </tr>


                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php else: ?>
                                        <p class="card-text"><strong>No existe información de detalles en este
                                                dispositivo</strong>
                                        </p>
                                    <?php endif; ?>

                                    <?php if($dispositivo->accesorios): ?>
                                        <div class="accordion my-3" id="accordionExampleA<?php echo e($loop->iteration); ?>">
                                            <div class="card">
                                                <div class="card-header" id="headingA<?php echo e($loop->iteration); ?>">
                                                    <h2 class="mb-0">
                                                        <button class="btn btn-link btn-block text-left" type="button"
                                                            data-toggle="collapse"
                                                            data-target="#collapseA<?php echo e($loop->iteration); ?>"
                                                            aria-expanded="false"
                                                            aria-controls="collapseA<?php echo e($loop->iteration); ?>">
                                                            Accesorios
                                                        </button>
                                                    </h2>
                                                </div>

                                                <div id="collapseA<?php echo e($loop->iteration); ?>" class="collapse"
                                                    aria-labelledby="headingA<?php echo e($loop->iteration); ?>"
                                                    data-parent="#accordionExampleA<?php echo e($loop->iteration); ?>">
                                                    <div class="card-body">
                                                        <table class="table table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th scope="col">Accesorios</th>
                                                                    <th scope="col">Descripción</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>Cargador</td>
                                                                    <td><?php echo e($dispositivo->accesorios->cargador_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Cable de poder</td>
                                                                    <td><?php echo e($dispositivo->accesorios->cable_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Adaptador de poder</td>
                                                                    <td><?php echo e($dispositivo->accesorios->adaptador_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Batería</td>
                                                                    <td><?php echo e($dispositivo->accesorios->bateria_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Pantalla en mal estado</td>
                                                                    <td><?php echo e($dispositivo->accesorios->pantalla_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Teclado en mal estado</td>
                                                                    <td><?php echo e($dispositivo->accesorios->teclado_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Drum</td>
                                                                    <td><?php echo e($dispositivo->accesorios->drum_acc); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Toner</td>
                                                                    <td><?php echo e($dispositivo->accesorios->toner_acc); ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php else: ?>
                                        <p class="card-text"><strong>No existe información de accesorios en este
                                                dispositivo</strong>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    <?php endif; ?>

                    <a href="<?php echo e(route('ordenes.index')); ?>" class="btn btn-primary">Volver</a>
                </div>
            </div>
        </div>
    </main>
    <script src="<?php echo e(asset('assets/js/ordenes/detalleOrden.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/ordenes/detalle.blade.php ENDPATH**/ ?>