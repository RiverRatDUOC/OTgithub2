<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Filtros -->
                <div class="d-flex justify-content-between align-items-center text-center mt-3">
                    <div class="d-flex flex-column align-items-start">
                        <h2>Filtrar Modelos</h2>
                        <form id="filter-form" action="<?php echo e(route('modelos.index')); ?>" method="get" class="input-group mt-3">
                            <div class="row g-2">
                                <div class="col-md-4 mb-2">
                                    <select name="categoria" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Categoría</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id); ?>" <?php echo e(request('categoria') == $categoria->id ? 'selected' : ''); ?>>
                                            <?php echo e($categoria->nombre_categoria); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <select name="subcategoria" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Subcategoría</option>
                                        <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subcategoria->id); ?>" <?php echo e(request('subcategoria') == $subcategoria->id ? 'selected' : ''); ?>>
                                            <?php echo e($subcategoria->nombre_subcategoria); ?> (<?php echo e($subcategoriaCounts[$subcategoria->id] ?? 0); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <select name="linea" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Línea</option>
                                        <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($linea->id); ?>" <?php echo e(request('linea') == $linea->id ? 'selected' : ''); ?>>
                                            <?php echo e($linea->nombre_linea); ?> (<?php echo e($lineaCounts[$linea->id] ?? 0); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <select name="sublinea" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Sublínea</option>
                                        <?php $__currentLoopData = $sublineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublinea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sublinea->id); ?>" <?php echo e(request('sublinea') == $sublinea->id ? 'selected' : ''); ?>>
                                            <?php echo e($sublinea->nombre_sublinea); ?> (<?php echo e($sublineaCounts[$sublinea->id] ?? 0); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <select name="marca" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Marca</option>
                                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($marca->id); ?>" <?php echo e(request('marca') == $marca->id ? 'selected' : ''); ?>>
                                            <?php echo e($marca->nombre_marca); ?> (<?php echo e($marcaCounts[$marca->id] ?? 0); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <select name="modelo" class="form-control form-control-sm w-100" onchange="this.form.submit()">
                                        <option value="">Seleccionar Modelo</option>
                                        <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($modelo->id); ?>" <?php echo e(request('modelo') == $modelo->id ? 'selected' : ''); ?>>
                                            <?php echo e($modelo->nombre_modelo); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Formulario de Búsqueda
                <div>
                    <form action="<?php echo e(route('modelos.buscar')); ?>" method="get" class="input-group mt-3">
                        <input type="text" name="search" id="search" class="form-control" placeholder="Buscar por ID, nombre, número de parte o descripción" value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Buscar</button>
                    </form>
                </div>-->

                <!-- Botones de Agregar y Eliminar Filtro -->
                <div class="d-flex align-items-center justify-content-end mt-3" style="gap: 1rem;">
                    <a href="<?php echo e(route('modelos.create')); ?>" class="btn btn-secondary btn-sm" style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-plus"></i> Agregar
                    </a>
                    <a href="<?php echo e(route('modelos.index')); ?>" class="btn btn-secondary btn-sm" style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-x-circle"></i> Eliminar Filtro
                    </a>
                </div>

                <!-- Tabla de Modelos -->
                <div class="table-responsive mt-3">
                    <table class="table table-striped" id="modelos_tabledata">
                        <thead>
                            <tr>
                                <th onclick="sortTable(0)">Categoría</th>
                                <th onclick="sortTable(1)">Subcategoría</th>
                                <th onclick="sortTable(2)">Línea</th>
                                <th onclick="sortTable(3)">Sublinea</th>
                                <th onclick="sortTable(4)">Marca</th>
                                <th onclick="sortTable(5)">Id</th>
                                <th onclick="sortTable(6)">Nombre Modelo</th>
                                <th onclick="sortTable(7)">Part Number</th>
                                <th onclick="sortTable(8)">Descripción Corta</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(optional($modelo->sublinea->linea->subcategoria->categoria)->nombre_categoria); ?></td>
                                <td><?php echo e(optional($modelo->sublinea->linea->subcategoria)->nombre_subcategoria); ?></td>
                                <td><?php echo e(optional($modelo->sublinea->linea)->nombre_linea); ?></td>
                                <td><?php echo e(optional($modelo->sublinea)->nombre_sublinea); ?></td>
                                <td><?php echo e(optional($modelo->marca)->nombre_marca); ?></td>
                                <td><?php echo e($modelo->id); ?></td>
                                <td><?php echo e($modelo->nombre_modelo); ?></td>
                                <td><?php echo e($modelo->part_number_modelo); ?></td>
                                <td><?php echo e($modelo->desc_corta_modelo); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('modelos.show', $modelo->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc0066; border-color: #cc0066; height: 38px; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('modelos.edit', $modelo->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc6633; border-color: #cc6633; height: 38px; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('modelos.destroy', $modelo->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" style="background-color: #d9534f; border-color: #d43f3a; height: 38px; display: flex; align-items: center; justify-content: center;">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <div class="d-flex justify-content-center mt-4">
                    <?php if($modelos->hasPages()): ?>
                    <nav>
                        <ul class="pagination" style="color: #cc6633;">
                            
                            <?php if($modelos->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&laquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($modelos->url(1)); ?>" rel="prev" style="color: #cc6633;">&laquo;</a>
                            </li>
                            <?php endif; ?>

                            
                            <?php if($modelos->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&lsaquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($modelos->previousPageUrl()); ?>" rel="prev" style="color: #cc6633;">&lsaquo;</a>
                            </li>
                            <?php endif; ?>

                            
                            <?php $__currentLoopData = $modelos->getUrlRange(max(1, $modelos->currentPage() - 5), min($modelos->lastPage(), $modelos->currentPage() + 5)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $modelos->currentPage()): ?>
                            <li class="page-item active" aria-current="page"><span class="page-link" style="background-color: #cc6633; border-color: #cc6633;"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>" style="color: #cc6633;"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <?php if($modelos->hasMorePages()): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($modelos->nextPageUrl()); ?>" rel="next" style="color: #cc6633;">&rsaquo;</a>
                            </li>
                            <?php else: ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&rsaquo;</span>
                            </li>
                            <?php endif; ?>

                            
                            <?php if($modelos->currentPage() == $modelos->lastPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&raquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($modelos->url($modelos->lastPage())); ?>" rel="next" style="color: #cc6633;">&raquo;</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('assets/js/mensajes/mensajes.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ordenar/OrdenarModelo.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/modelos/modelos.blade.php ENDPATH**/ ?>