<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <main id="main-content" class="col bg-faded py-3 flex-grow-1">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <!-- Detalle del Técnico -->
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <h2>Detalle del Técnico</h2>
                        <a href="<?php echo e(route('tecnicos.index')); ?>" class="btn btn-secondary"
                            style="background-color: #cc6633; border-color: #cc6633;">
                            <i class="bi bi-arrow-left"></i> Regresar
                        </a>
                    </div>

                    <!-- Información del Técnico -->
                    <div class="card mt-3">
                        <div class="card-header">
                            Información del Técnico
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>RUT</th>
                                        <th>Teléfono</th>
                                        <th>Email</th>
                                        <th>Precio por Hora</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($tecnico->nombre_tecnico); ?></td>
                                        <td><?php echo e($tecnico->rut_tecnico); ?></td>
                                        <td><?php echo e($tecnico->telefono_tecnico); ?></td>
                                        <td><?php echo e($tecnico->email_tecnico); ?></td>
                                        <td>$<?php echo e(number_format($tecnico->precio_hora_tecnico, 2, ',', '.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Información del Usuario Asociado -->
                    <?php if($tecnico->usuario): ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                Información del Usuario Asociado
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Nombre de Usuario</th>
                                            <th>Email</th>
                                            <th>Rol</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($tecnico->usuario->nombre_usuario); ?></td>
                                            <td><?php echo e($tecnico->usuario->email_usuario); ?></td>
                                            <td><?php echo e($tecnico->usuario->rol_usuario); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                Información del Usuario Asociado
                            </div>
                            <div class="card-body">
                                <p>No hay usuario asociado.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/tecnicos/detalle.blade.php ENDPATH**/ ?>