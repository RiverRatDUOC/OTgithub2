<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Agregar Modelo -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Agregar Modelo</h2>
                </div>

                <!-- Sección Tutorial -->
                <div class="alert alert-info mt-4" role="alert">
                    <h5 class="alert-heading">Tutorial</h5>
                    <p>Agregue la siguiente información para agregar un modelo correctamente:</p>
                    <ul>
                        <li><strong>Categoría:</strong> Seleccione la categoría a la que pertenece el modelo.</li>
                        <li><strong>Subcategoría:</strong> Seleccione la subcategoría del modelo.</li>
                        <li><strong>Línea:</strong> Seleccione la línea del modelo.</li>
                        <li><strong>Sublínea:</strong> Seleccione la sublínea del modelo.</li>
                        <li><strong>Nombre del Modelo:</strong> Nombre completo del modelo.</li>
                        <li><strong>Número de Parte:</strong> Número de parte del modelo, si está disponible.</li>
                        <li><strong>Descripción Corta:</strong> Descripción breve del modelo.</li>
                        <li><strong>Descripción Larga:</strong> Descripción detallada del modelo.</li>
                        <li><strong>Marca:</strong> Seleccione la marca del modelo.</li>
                    </ul>
                </div>

                <!-- Formulario de Adición -->
                <div class="card mt-3">
                    <div class="card-header">
                        Agregar Información del Modelo
                    </div>
                    <div class="card-body">

                        <!-- Mensaje de éxito -->
                        <?php if(session('success')): ?>
                        <div id="success-message" class="d-none">
                            <span id="success-type"><?php echo e(session('success_type', 'agregar')); ?></span>
                            <span id="module-name">Modelo</span>
                            <span id="redirect-url"><?php echo e(route('modelos.index')); ?></span>
                        </div>
                        <?php endif; ?>

                        <!-- Mensaje de error -->
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('modelos.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <!-- Selección de Categoría -->
                            <div class="form-group">
                                <label for="cod_categoria">Categoría</label>
                                <select name="cod_categoria" id="cod_categoria" class="form-control" required>
                                    <option value="">Seleccionar Categoría</option>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->id); ?>" <?php echo e(old('cod_categoria') == $categoria->id ? 'selected' : ''); ?>>
                                        <?php echo e($categoria->nombre_categoria); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cod_categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Selección de Subcategoría -->
                            <div class="form-group">
                                <label for="cod_subcategoria">Subcategoría</label>
                                <select name="cod_subcategoria" id="cod_subcategoria" class="form-control" required>
                                    <option value="">Seleccionar Subcategoría</option>
                                    <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategoria->id); ?>" <?php echo e(old('cod_subcategoria') == $subcategoria->id ? 'selected' : ''); ?>>
                                        <?php echo e($subcategoria->nombre_subcategoria); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cod_subcategoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Selección de Línea -->
                            <div class="form-group">
                                <label for="cod_linea">Línea</label>
                                <select name="cod_linea" id="cod_linea" class="form-control" required>
                                    <option value="">Seleccionar Línea</option>
                                    <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($linea->id); ?>" <?php echo e(old('cod_linea') == $linea->id ? 'selected' : ''); ?>>
                                        <?php echo e($linea->nombre_linea); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cod_linea'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Selección de Sublínea -->
                            <div class="form-group">
                                <label for="cod_sublinea">Sublínea</label>
                                <select name="cod_sublinea" id="cod_sublinea" class="form-control" required>
                                    <option value="">Seleccionar Sublínea</option>
                                    <?php $__currentLoopData = $sublineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublinea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sublinea->id); ?>" <?php echo e(old('cod_sublinea') == $sublinea->id ? 'selected' : ''); ?>>
                                        <?php echo e($sublinea->nombre_sublinea); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cod_sublinea'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Información del Modelo -->
                            <div class="form-group">
                                <label for="nombre_modelo">Nombre del Modelo</label>
                                <input type="text" name="nombre_modelo" id="nombre_modelo" class="form-control" value="<?php echo e(old('nombre_modelo')); ?>" required>
                                <?php $__errorArgs = ['nombre_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="part_number_modelo">Número de Parte</label>
                                <input type="text" name="part_number_modelo" id="part_number_modelo" class="form-control" value="<?php echo e(old('part_number_modelo')); ?>">
                                <?php $__errorArgs = ['part_number_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="desc_corta_modelo">Descripción Corta</label>
                                <textarea name="desc_corta_modelo" id="desc_corta_modelo" class="form-control"><?php echo e(old('desc_corta_modelo')); ?></textarea>
                                <?php $__errorArgs = ['desc_corta_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="desc_larga_modelo">Descripción Larga</label>
                                <textarea name="desc_larga_modelo" id="desc_larga_modelo" class="form-control"><?php echo e(old('desc_larga_modelo')); ?></textarea>
                                <?php $__errorArgs = ['desc_larga_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Selección de Marca -->
                            <div class="form-group">
                                <label for="cod_marca">Marca</label>
                                <select name="cod_marca" id="cod_marca" class="form-control" required>
                                    <option value="">Seleccionar Marca</option>
                                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($marca->id); ?>" <?php echo e(old('cod_marca') == $marca->id ? 'selected' : ''); ?>>
                                        <?php echo e($marca->nombre_marca); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cod_marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <!-- Botón Guardar -->
                                <button type="submit" class="btn btn-primary" style="background-color: #cc0066; border-color: #cc0066;">
                                    <i class="fas fa-save"></i> Guardar
                                </button>

                                <!-- Botón Cancelar -->
                                <a href="<?php echo e(route('modelos.index')); ?>" class="btn btn-secondary" style="background-color: #cc0066; border-color: #cc0066;">
                                    <i class="fas fa-times-circle"></i> Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Incluye el archivo JavaScript -->
<script src="<?php echo e(asset('assets/js/mensajes/mensajes.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/modelos/filtromodelos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/modelos/agregar.blade.php ENDPATH**/ ?>