<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="d-flex justify-content-between align-items-center text-center mt-3">
                    <h2>Tareas</h2>
                    <div class="d-flex align-items-center">
                        <a href="<?php echo e(route('tareas.create')); ?>" class="btn btn-primary ms-auto" style="background-color: #cc6633; border-color: #cc6633;">
                            <i class="bi bi-plus"></i> Agregar
                        </a>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mt-3">
                    <form action="<?php echo e(route('tareas.buscar')); ?>" method="get" class="input-group">
                        <input type="text" name="search" id="search" class="form-control" placeholder="Buscar por...">
                        <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Buscar</button>
                    </form>
                </div>

                <div class="table-responsive mt-3">
                    <table class="table table-striped" id="tareas_tabledata">
                        <thead>
                            <tr>
                                <th onclick="sortTable(0)">Id</th>
                                <th onclick="sortTable(1)">Nombre Tarea</th>
                                <th onclick="sortTable(2)">Nombre Servicio</th> <!-- Cambié el encabezado -->
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tarea->id); ?></td>
                                <td><?php echo e($tarea->nombre_tarea); ?></td>
                                <td><?php echo e(optional($tarea->servicio)->nombre_servicio); ?></td> <!-- Mostrar el nombre del servicio -->
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('tareas.show', $tarea->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc0066; border-color: #cc0066; height: 38px; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('tareas.edit', $tarea->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc6633; border-color: #cc6633; height: 38px; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('tareas.destroy', $tarea->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" style="background-color: #d9534f; border-color: #d43f3a; height: 38px; display: flex; align-items: center; justify-content: center;">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


                <div class="d-flex justify-content-center mt-4">
                    <?php if($tareas->hasPages()): ?>
                    <nav>
                        <ul class="pagination" style="color: #cc6633;">
                            
                            <?php if($tareas->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&laquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($tareas->url(1)); ?>" rel="prev" style="color: #cc6633;">&laquo;</a>
                            </li>
                            <?php endif; ?>

                            
                            <?php if($tareas->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&lsaquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($tareas->previousPageUrl()); ?>" rel="prev" style="color: #cc6633;">&lsaquo;</a>
                            </li>
                            <?php endif; ?>

                            
                            <?php $__currentLoopData = $tareas->getUrlRange(max(1, $tareas->currentPage() - 5), min($tareas->lastPage(), $tareas->currentPage() + 5)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $tareas->currentPage()): ?>
                            <li class="page-item active" aria-current="page"><span class="page-link" style="background-color: #cc6633; border-color: #cc6633;"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>" style="color: #cc6633;"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <?php if($tareas->hasMorePages()): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($tareas->nextPageUrl()); ?>" rel="next" style="color: #cc6633;">&rsaquo;</a>
                            </li>
                            <?php else: ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&rsaquo;</span>
                            </li>
                            <?php endif; ?>

                            
                            <?php if($tareas->currentPage() == $tareas->lastPage()): ?>
                            <li class="page-item disabled" aria-disabled="true">
                                <span class="page-link" style="color: #cc6633;">&raquo;</span>
                            </li>
                            <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($tareas->url($tareas->lastPage())); ?>" rel="next" style="color: #cc6633;">&raquo;</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="<?php echo e(asset('assets/js/ordenar/OrdenarTareas.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/tareas/tareas.blade.php ENDPATH**/ ?>