<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Avances de la OT: <?php echo e($orden->numero_ot); ?></h2>
                </div>

                <!-- Mostrar lista de avances -->
                <div class="card mt-4">
                    <div class="card-header">Lista de Avances</div>
                    <div class="card-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $orden->avances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <strong><?php echo e($avance->fecha_avance); ?>:</strong>
                                <?php echo e($avance->comentario_avance); ?>

                                <span class="badge bg-info"><?php echo e($avance->tiempo_avance); ?> horas</span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <!-- Verifica si la OT está finalizada -->
                <?php if($orden->estado->descripcion_estado_ot !== 'Finalizada'): ?>
                <!-- Formulario para agregar nuevo avance -->
                <div class="card mt-4">
                    <div class="card-header">Agregar Avance</div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('ordenes.avances.store', $orden->numero_ot)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="comentario_avance">Comentario</label>
                                <input type="text" name="comentario_avance" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="fecha_avance">Fecha</label>
                                <input type="date" name="fecha_avance" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="tiempo_avance">Tiempo en Horas</label>
                                <input type="number" name="tiempo_avance" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-primary" style="background-color: #cc0066; border-color: #cc0066;">
                                <i class="fas fa-save"></i> Guardar Avance
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Formulario para finalizar la OT -->
                <div class="card mt-4">
                    <div class="card-header">Finalizar OT</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('ordenes.finalizar', $orden->numero_ot)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="comentario_avance">Comentario Final</label>
                                <input type="text" name="comentario_avance" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="fecha_avance">Fecha Final</label>
                                <input type="date" name="fecha_avance" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="tiempo_avance">Tiempo en Horas</label>
                                <input type="number" name="tiempo_avance" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-success" style="background-color: #28a745;">
                                <i class="fas fa-check-circle"></i> Finalizar OT
                            </button>
                        </form>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    <strong>La OT ya está finalizada.</strong> No se pueden agregar más avances ni finalizarla.
                </div>
                <?php endif; ?>

                <!-- Mostrar último avance (para la finalización) -->
                <?php if($orden->avances->isNotEmpty()): ?>
                <div class="card mt-4">
                    <div class="card-header">Último Avance para la Finalización</div>
                    <div class="card-body">
                        <p><strong>Comentario:</strong> <?php echo e($orden->avances->last()->comentario_avance); ?></p>
                        <p><strong>Fecha:</strong> <?php echo e($orden->avances->last()->fecha_avance); ?></p>
                        <p><strong>Tiempo:</strong> <?php echo e($orden->avances->last()->tiempo_avance); ?> horas</p>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/ordenes/avances.blade.php ENDPATH**/ ?>