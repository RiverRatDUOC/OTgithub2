 <!-- Ajusta esto según tu estructura de vistas -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Órdenes Asignadas a <?php echo e($tecnico->nombre_tecnico); ?></h1>

    <?php if($ordenes->isEmpty()): ?>
    <p>No hay órdenes asignadas a este técnico.</p>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Número OT</th>
                <th>Descripción</th>
                <th>Estado</th>
                <th>Fecha Fin Planificada</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($orden->numero_ot); ?></td>
                <td><?php echo e($orden->descripcion_ot); ?></td>
                <td><?php echo e($orden->estado->descripcion_estado_ot); ?></td>
                <td style="width:10%"><?php echo e(date('d-m-Y', strtotime($orden->created_at))); ?></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($ordenes->links()); ?> <!-- Paginación -->
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/tecnicosot/index.blade.php ENDPATH**/ ?>