<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Detalle de la Sucursal -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Detalle de la Sucursal</h2>
                    <a href="<?php echo e(route('sucursales.index')); ?>" class="btn btn-secondary" style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-arrow-left"></i> Regresar
                    </a>
                </div>

                <!-- Información de la Sucursal -->
                <div class="card mt-3">
                    <div class="card-header">
                        Información de la Sucursal
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Dirección</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($sucursal->nombre_sucursal); ?></td>
                                    <td><?php echo e($sucursal->telefono_sucursal); ?></td>
                                    <td><?php echo e($sucursal->direccion_sucursal); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Información del Cliente Asociado -->
                <?php if($sucursal->cliente): ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Información del Cliente Asociado
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nombre Cliente</th>
                                    <th>RUT Cliente</th>
                                    <th>Teléfono Cliente</th>
                                    <th>Email Cliente</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($sucursal->cliente->nombre_cliente); ?></td>
                                    <td><?php echo e($sucursal->cliente->rut_cliente); ?></td>
                                    <td><?php echo e($sucursal->cliente->telefono_cliente); ?></td>
                                    <td><?php echo e($sucursal->cliente->email_cliente); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php else: ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Información del Cliente Asociado
                    </div>
                    <div class="card-body">
                        <p>No hay cliente asociado.</p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Contactos Asociados -->
                <?php if($sucursal->contacto->isEmpty()): ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Contactos Asociados
                    </div>
                    <div class="card-body">
                        <p>No hay contactos asociados.</p>
                    </div>
                </div>
                <?php else: ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Contactos Asociados
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Departamento</th>
                                    <th>Cargo</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sucursal->contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contacto->nombre_contacto); ?></td>
                                    <td><?php echo e($contacto->telefono_contacto); ?></td>
                                    <td><?php echo e($contacto->departamento_contacto); ?></td>
                                    <td><?php echo e($contacto->cargo_contacto); ?></td>
                                    <td><?php echo e($contacto->email_contacto); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Dispositivos Asociados -->
                <?php if($sucursal->dispositivo->isEmpty()): ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Dispositivos Asociados
                    </div>
                    <div class="card-body">
                        <p>No hay dispositivos asociados.</p>
                    </div>
                </div>
                <?php else: ?>
                <div class="card mt-3">
                    <div class="card-header">
                        Dispositivos Asociados
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Número de Serie</th>
                                    <th>Modelo</th>
                                    <th>Descripción Corta</th>
                                    <th>Descripción Larga</th>
                                    <th>Part Number</th>
                                    <th>Marca</th>
                                    <th>Sublinea</th>
                                    <th>Linea</th>
                                    <th>Subcategoría</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sucursal->dispositivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dispositivo->numero_serie_dispositivo); ?></td>
                                    <td><?php echo e($dispositivo->modelo->nombre_modelo ?? 'No asignado'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->desc_corta_modelo ?? 'No disponible'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->desc_larga_modelo ?? 'No disponible'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->part_number_modelo ?? 'No disponible'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->marca->nombre_marca ?? 'No asignada'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->sublinea->nombre_sublinea ?? 'No asignada'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->sublinea->linea->nombre_linea ?? 'No asignada'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->sublinea->linea->subcategoria->nombre_subcategoria ?? 'No asignada'); ?></td>
                                    <td><?php echo e($dispositivo->modelo->sublinea->linea->subcategoria->categoria->nombre_categoria ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/sucursales/detalle.blade.php ENDPATH**/ ?>