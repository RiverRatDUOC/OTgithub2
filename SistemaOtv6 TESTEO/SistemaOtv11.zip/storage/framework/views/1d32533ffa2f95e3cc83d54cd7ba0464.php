<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <h2 class="mb-4">Editar Línea</h2>

        <form action="<?php echo e(route('lineas.update', $linea->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="nombre_linea">Nombre de la Línea</label>
                <input type="text" name="nombre_linea" class="form-control"
                    value="<?php echo e($linea->nombre_linea); ?>" required>
            </div>

            <div class="form-group">
                <label for="cod_subcategoria">Subcategoría</label>
                <select name="cod_subcategoria" id="cod_subcategoria" class="form-control" required>
                    <option value="">Seleccione una subcategoría</option>
                    <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subcategoria->id); ?>" <?php echo e($linea->cod_subcategoria == $subcategoria->id ? 'selected' : ''); ?>>
                        <?php echo e($subcategoria->nombre_subcategoria); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-success" style="background-color: #cc6633;">Guardar cambios</button>
            <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/lineas/editar.blade.php ENDPATH**/ ?>