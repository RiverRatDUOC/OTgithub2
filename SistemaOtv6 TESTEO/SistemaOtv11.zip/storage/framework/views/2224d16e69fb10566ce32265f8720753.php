<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <h2 class="mb-4">Editar Sublínea</h2>

        <form action="<?php echo e(route('sublineas.update', $sublinea->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="nombre_sublinea">Nombre de la Sublínea</label>
                <input type="text" name="nombre_sublinea" class="form-control"
                    value="<?php echo e($sublinea->nombre_sublinea); ?>" required>
            </div>

            <div class="form-group">
                <label for="cod_linea">Línea</label>
                <select name="cod_linea" id="cod_linea" class="form-control" required>
                    <option value="">Seleccione una línea</option>
                    <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($linea->id); ?>" <?php echo e($sublinea->cod_linea == $linea->id ? 'selected' : ''); ?>>
                        <?php echo e($linea->nombre_linea); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-success" style="background-color: #cc6633;">Guardar cambios</button>
            <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/sublineas/editar.blade.php ENDPATH**/ ?>