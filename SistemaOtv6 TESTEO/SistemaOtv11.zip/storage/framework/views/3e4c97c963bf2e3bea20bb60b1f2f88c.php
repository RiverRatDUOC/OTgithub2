<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Detalle de la Subcategoría -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Detalle de la Subcategoría</h2>
                    <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary"
                        style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-arrow-left"></i> Regresar
                    </a>
                </div>

                <!-- Información de la Subcategoría -->
                <div class="card mt-3">
                    <div class="card-header">
                        Subcategoría: <?php echo e($subcategoria->nombre_subcategoria); ?>

                    </div>
                    <div class="card-body">
                        <p><strong>Nombre:</strong> <?php echo e($subcategoria->nombre_subcategoria); ?></p>
                        <p><strong>Categoría:</strong> <?php echo e($subcategoria->categoria->nombre_categoria ?? 'No asignada'); ?></p>
                        <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-primary"
                            style="background-color: #cc6633;">Volver a la lista</a>
                        <a href="<?php echo e(route('subcategorias.edit', $subcategoria->id)); ?>" class="btn btn-warning"
                            style="background-color: #cc6633;">Editar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/subcategoria/detalle.blade.php ENDPATH**/ ?>