<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <h2 class="mb-4">Editar Subcategoría</h2>

        <form action="<?php echo e(route('subcategorias.update', $subcategoria->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nombre_subcategoria">Nombre de la Subcategoría</label>
                <input type="text" name="nombre_subcategoria" class="form-control"
                    value="<?php echo e($subcategoria->nombre_subcategoria); ?>" required>
            </div>

            <div class="form-group">
                <label for="cod_categoria">Categoría</label>
                <select name="cod_categoria" id="cod_categoria" class="form-control" required>
                    <option value="">Seleccione una categoría</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" <?php echo e($subcategoria->cod_categoria == $categoria->id ? 'selected' : ''); ?>>
                        <?php echo e($categoria->nombre_categoria); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-success" style="background-color: #cc6633;">Guardar cambios</button>
            <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/subcategoria/editar.blade.php ENDPATH**/ ?>