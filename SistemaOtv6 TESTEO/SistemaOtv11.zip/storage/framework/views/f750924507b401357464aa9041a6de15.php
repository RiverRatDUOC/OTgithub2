<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main id="main-content" class="col bg-faded py-3 flex-grow-1">
        <div class="container-fluid">
            <h2 class="mb-4">Editar Categoría</h2>

            <form action="<?php echo e(route('categoria.update', $categoria->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nombre_categoria">Nombre de la Categoría</label>
                    <input type="text" name="nombre_categoria" class="form-control"
                        value="<?php echo e($categoria->nombre_categoria); ?>" required>
                </div>
                <button type="submit" class="btn btn-success" style="background-color: #cc6633;">Guardar cambios</button>
                <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/categoria/editar.blade.php ENDPATH**/ ?>