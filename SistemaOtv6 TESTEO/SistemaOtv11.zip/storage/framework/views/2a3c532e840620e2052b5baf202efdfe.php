<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Detalle del Dispositivo -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Detalle del Dispositivo</h2>
                    <a href="<?php echo e(route('dispositivos.index')); ?>" class="btn btn-secondary" style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-arrow-left"></i> Volver a la lista
                    </a>
                </div>

                <!-- Información del Dispositivo -->
                <div class="card mt-3">
                    <div class="card-header">
                        Información del Dispositivo
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Número de Serie</th>
                                    <th>Modelo</th>
                                    <th>Sucursal</th>
                                    <th>Creado en</th>
                                    <th>Actualizado en</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($dispositivo->numero_serie_dispositivo); ?></td>
                                    <td><?php echo e($dispositivo->modelo->nombre_modelo); ?></td>
                                    <td><?php echo e($dispositivo->sucursal->nombre_sucursal); ?></td>
                                    <td><?php echo e($dispositivo->created_at); ?></td>
                                    <td><?php echo e($dispositivo->updated_at); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/dispositivo/detalle.blade.php ENDPATH**/ ?>