<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Detalle del Cliente -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Detalle del Cliente</h2>
                    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary" style="background-color: #cc6633; border-color: #cc6633;">
                        <i class="bi bi-arrow-left"></i> Regresar
                    </a>
                </div>

                <!-- Información del Cliente -->
                <div class="card mt-3">
                    <div class="card-header">
                        Información del Cliente
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>RUT</th>
                                    <th>Correo</th>
                                    <th>Teléfono</th>
                                    <th>Sitio Web</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($cliente->nombre_cliente ?? 'No disponible'); ?></td>
                                    <td><?php echo e($cliente->rut_cliente ?? 'No disponible'); ?></td>
                                    <td><?php echo e($cliente->email_cliente ?? 'No disponible'); ?></td>
                                    <td><?php echo e($cliente->telefono_cliente ?? 'No disponible'); ?></td>
                                    <td><?php echo e($cliente->web_cliente ?? 'No disponible'); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Información de Sucursales Asociadas -->
                <div class="card mt-3">
                    <div class="card-header">
                        Sucursales Asociadas
                    </div>
                    <div class="card-body">
                        <?php if($cliente->sucursal->isEmpty()): ?>
                        <p>No hay sucursales asociadas.</p>
                        <?php else: ?>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Dirección</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cliente->sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sucursal->nombre_sucursal ?? 'No disponible'); ?></td>
                                    <td><?php echo e($sucursal->telefono_sucursal ?? 'No disponible'); ?></td>
                                    <td><?php echo e($sucursal->direccion_sucursal ?? 'No disponible'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/clientes/detalle.blade.php ENDPATH**/ ?>