<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center text-center mt-3">
            <h2>Roles</h2>
            <div class="d-flex align-items-center">
                <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary ms-auto" style="background-color: #cc6633; border-color: #cc6633;">
                    <i class="bi bi-plus"></i> Agregar
                </a>
            </div>
        </div>

        <form action="<?php echo e(route('roles.buscar')); ?>" method="GET" class="input-group mt-3">
            <input type="text" name="search" id="search" class="form-control" placeholder="Buscar por..." style="border-color: #cc6633;">
            <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Buscar</button>
        </form>

        <div class="table-responsive mt-2">
            <table class="table table-bordered table-striped text-center shadow">
                <thead class="table-primary">
                    <tr>
                        <th>#ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->id); ?></td>
                        <td>
                            <span class="badge" style="background-color: <?php echo e($role->color); ?>; color: white;"><?php echo e($role->name); ?></span>
                        </td>
                        <td><?php echo e($role->description); ?></td>
                        <td>
                            <div class="d-flex justify-content-center align-items-center">
                                <form action="<?php echo e(route('roles.edit', $role->id)); ?>" method="GET" style="margin-right: 10px;">
                                    <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                </form>
                                <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" onsubmit="return confirm('¿Está seguro de eliminar este rol?')" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">
                                        <i class="fas fa-trash-alt"></i> Eliminar
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-4">
            <?php echo e($roles->links()); ?>

        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/roles/roles.blade.php ENDPATH**/ ?>