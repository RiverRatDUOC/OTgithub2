<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">

<main class="col bg-faded py-3 flex-grow-1">
    <h3>Home / Roles / Editar</h3>
    <br>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center text-center mt-3">
            <h2>Editar Rol</h2>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="name" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($role->name); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Descripción</label>
                        <input type="text" class="form-control" id="description" name="description" value="<?php echo e($role->description); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="color" class="form-label">Color</label>
                        <input type="color" class="form-control" id="color" name="color" value="<?php echo e($role->color); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="permissions" class="form-label">Permisos</label>
                        <div class="form-check">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" id="permission_<?php echo e($permission->id); ?>" <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>">
                                    <?php echo e($permission->description); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="background-color: #cc6633; border-color: #cc6633;">Guardar Cambios</button>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/roles/editar.blade.php ENDPATH**/ ?>