<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Encabezado -->
                <div class="d-flex justify-content-between align-items-center mt-3 mb-2">
                    <h4>Datos de Parámetros</h4>
                </div>

                <!-- Categorías -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Categorías</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($categoria->id); ?></td>
                                        <td><?php echo e($categoria->nombre_categoria); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Subcategorías -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Subcategorías</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Categoría</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($subcategoria->id); ?></td>
                                        <td><?php echo e($subcategoria->nombre_subcategoria); ?></td>
                                        <td><?php echo e($subcategoria->categoria->nombre_categoria ?? 'No asignada'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Líneas -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Líneas</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Subcategoría</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($linea->id); ?></td>
                                        <td><?php echo e($linea->nombre_linea); ?></td>
                                        <td><?php echo e($linea->subcategoria->nombre_subcategoria ?? 'No asignada'); ?></td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('lineas.show', $linea->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc0066; border-color: #cc0066;">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Sublíneas -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Sublíneas</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Línea</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $sublineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublinea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sublinea->id); ?></td>
                                        <td><?php echo e($sublinea->nombre_sublinea); ?></td>
                                        <td><?php echo e($sublinea->linea->nombre_linea ?? 'No asignada'); ?></td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('parametros.show', $sublinea->id)); ?>" class="btn btn-primary me-1" style="background-color: #cc0066; border-color: #cc0066;">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Marcas -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Marcas</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($marca->id); ?></td>
                                        <td><?php echo e($marca->nombre_marca); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>

                <!-- Tipo de OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Tipos de OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                        </table>
                        <div style="overflow-y: auto; max-height: 300px;">
                            <table class="table table-striped" style="width: 100%;">
                                <tbody>
                                    <?php $__currentLoopData = $tipos_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tipo_ot->id); ?></td>
                                        <td><?php echo e($tipo_ot->descripcion_tipo_ot); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>
                <!-- Prioridades de OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Prioridades de OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $prioridades_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prioridad_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($prioridad_ot->id); ?></td>
                                    <td><?php echo e($prioridad_ot->descripcion_prioridad_ot); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <!-- Estados de OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Estados de OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $estados_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($estado_ot->id); ?></td>
                                    <td><?php echo e($estado_ot->descripcion_estado_ot); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Tipos de Visita -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Tipos de Visita</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tipos_visita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tipo_visita->id); ?></td>
                                    <td><?php echo e($tipo_visita->descripcion_tipo_visita); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Tipos de Servicio -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Tipos de Servicio</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tipos_servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tipo_servicio->id); ?></td>
                                    <td><?php echo e($tipo_servicio->descripcion_tipo_servicio); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Modelos -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Modelos</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Descripción Corta</th>
                                    <th>Descripción Larga</th>
                                    <th>Part Number</th>
                                    <th>Marca</th>
                                    <th>Sublínea</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($modelo->id); ?></td>
                                    <td><?php echo e($modelo->nombre_modelo); ?></td>
                                    <td><?php echo e($modelo->desc_corta_modelo); ?></td>
                                    <td><?php echo e($modelo->desc_larga_modelo); ?></td>
                                    <td><?php echo e($modelo->part_number_modelo); ?></td>
                                    <td><?php echo e($modelo->marca->nombre_marca ?? 'No asignada'); ?></td>
                                    <td><?php echo e($modelo->sublinea->nombre_sublinea ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>


                <!-- Usuarios -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Usuarios</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>Rol</th>
                                    <th>Email Verificado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($usuario->id); ?></td>
                                    <td><?php echo e($usuario->nombre_usuario); ?></td>
                                    <td><?php echo e($usuario->email_usuario); ?></td>
                                    <td><?php echo e($usuario->rol_usuario); ?></td>
                                    <td><?php echo e($usuario->email_verified_at ? $usuario->email_verified_at->format('Y-m-d H:i:s') : 'No'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Técnicos -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Técnicos</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>RUT</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Precio por Hora</th>
                                    <th>Usuario Asociado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tecnico->id); ?></td>
                                    <td><?php echo e($tecnico->nombre_tecnico); ?></td>
                                    <td><?php echo e($tecnico->rut_tecnico); ?></td>
                                    <td><?php echo e($tecnico->telefono_tecnico); ?></td>
                                    <td><?php echo e($tecnico->email_tecnico); ?></td>
                                    <td>$<?php echo e(number_format($tecnico->precio_hora_tecnico, )); ?></td>
                                    <td><?php echo e($tecnico->usuario->nombre_usuario ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Clientes -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Clientes</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>RUT</th>
                                    <th>Web</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cliente->id); ?></td>
                                    <td><?php echo e($cliente->nombre_cliente); ?></td>
                                    <td><?php echo e($cliente->rut_cliente); ?></td>
                                    <td><?php echo e($cliente->web_cliente); ?></td>
                                    <td><?php echo e($cliente->telefono_cliente); ?></td>
                                    <td><?php echo e($cliente->email_cliente); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <!-- Sucursales -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Sucursales</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Dirección</th>
                                    <th>Cliente</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sucursal->id); ?></td>
                                    <td><?php echo e($sucursal->nombre_sucursal); ?></td>
                                    <td><?php echo e($sucursal->telefono_sucursal); ?></td>
                                    <td><?php echo e($sucursal->direccion_sucursal); ?></td>
                                    <td><?php echo e($sucursal->cliente->nombre_cliente ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Contactos -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Contactos</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Teléfono</th>
                                    <th>Departamento</th>
                                    <th>Cargo</th>
                                    <th>Email</th>
                                    <th>Sucursal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contacto->id); ?></td>
                                    <td><?php echo e($contacto->nombre_contacto); ?></td>
                                    <td><?php echo e($contacto->telefono_contacto); ?></td>
                                    <td><?php echo e($contacto->departamento_contacto); ?></td>
                                    <td><?php echo e($contacto->cargo_contacto); ?></td>
                                    <td><?php echo e($contacto->email_contacto); ?></td>
                                    <td><?php echo e($contacto->sucursal->nombre_sucursal ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Servicios -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Servicios</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Tipo de Servicio</th>
                                    <th>Sublínea</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($servicio->id); ?></td>
                                    <td><?php echo e($servicio->nombre_servicio); ?></td>
                                    <td><?php echo e($servicio->tipoServicio->descripcion_tipo_servicio ?? 'No asignado'); ?></td>
                                    <td><?php echo e($servicio->sublinea->nombre_sublinea ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Técnico-Servicios -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Técnico-Servicios</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Técnico</th>
                                    <th>Servicio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tecnico_servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico_servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tecnico_servicio->id); ?></td>
                                    <td><?php echo e($tecnico_servicio->tecnico->nombre_tecnico ?? 'No asignado'); ?></td>
                                    <td><?php echo e($tecnico_servicio->servicio->nombre_servicio ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Tareas -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Tareas</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Tiempo</th>
                                    <th>Servicio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tarea->id); ?></td>
                                    <td><?php echo e($tarea->nombre_tarea); ?></td>
                                    <td><?php echo e($tarea->tiempo_tarea); ?></td>
                                    <td><?php echo e($tarea->servicio->nombre_servicio ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Dispositivos -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Dispositivos</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Número de Serie</th>
                                    <th>Modelo</th>
                                    <th>Sucursal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dispositivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dispositivo->id); ?></td>
                                    <td><?php echo e($dispositivo->numero_serie_dispositivo); ?></td>
                                    <td><?php echo e($dispositivo->modelo->nombre_modelo ?? 'No asignado'); ?></td>
                                    <td><?php echo e($dispositivo->sucursal->nombre_sucursal ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Dispositivos OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Dispositivos OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Dispositivo</th>
                                    <th>OT</th>
                                    <th>Detalles</th>
                                    <th>Accesorios</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dispositivos_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dispositivo_ot->id); ?></td>
                                    <td><?php echo e($dispositivo_ot->dispositivo->numero_serie_dispositivo ?? 'No asignado'); ?></td>
                                    <td><?php echo e($dispositivo_ot->ot->numero_ot ?? 'No asignado'); ?></td>
                                    <td><?php echo e($dispositivo_ot->detalles ? 'Sí' : 'No'); ?></td>
                                    <td><?php echo e($dispositivo_ot->accesorios ? 'Sí' : 'No'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Tareas OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Tareas OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Tarea</th>
                                    <th>OT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tareas_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tarea_ot->id); ?></td>
                                    <td><?php echo e($tarea_ot->tarea->nombre_tarea ?? 'No asignada'); ?></td>
                                    <td><?php echo e($tarea_ot->ot->numero_ot ?? 'No asignada'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Contactos OT -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Contactos OT</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Contacto</th>
                                    <th>OT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contactos_ot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto_ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contacto_ot->id); ?></td>
                                    <td><?php echo e($contacto_ot->contacto->nombre_contacto ?? 'No asignado'); ?></td>
                                    <td><?php echo e($contacto_ot->ot->numero_ot ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
                <!-- Equipos Técnicos -->
                <details style="width: 100%;">
                    <summary style="font-size: 1.25rem; padding: 10px; border: 1px solid #ddd; background-color: #f7f7f7; cursor: pointer; width: 100%;">Equipos Técnicos</summary>
                    <div class="table-responsive mt-3" style="max-height: 300px; overflow-y: auto; width: 100%;">
                        <table class="table table-striped" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Técnico</th>
                                    <th>OT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $equipos_tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo_tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($equipo_tecnico->id); ?></td>
                                    <td><?php echo e($equipo_tecnico->tecnico->nombre_tecnico ?? 'No asignado'); ?></td>
                                    <td><?php echo e($equipo_tecnico->ot->numero_ot ?? 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>


            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/parametros/parametros.blade.php ENDPATH**/ ?>