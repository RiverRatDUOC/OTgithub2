<?php echo $__env->make('layouts.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(URL::to('assets/css/profile.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<main id="main-content" class="col bg-faded py-3 flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <!-- Agregar Técnico -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h2>Agregar Técnico</h2>
                </div>

                <!-- Sección Tutorial -->
                <div class="alert alert-info mt-4" role="alert">
                    <h5 class="alert-heading">Instrucciones</h5>
                    <p>Complete la siguiente información para agregar un técnico correctamente:</p>
                    <ul>
                        <li><strong>Nombre del Técnico:</strong> Nombre del técnico.</li>
                        <li><strong>RUT:</strong> RUT del técnico.</li>
                        <li><strong>Teléfono:</strong> Número de teléfono del técnico.</li>
                        <li><strong>Email:</strong> Correo electrónico del técnico.</li>
                        <li><strong>Precio por Hora:</strong> Tarifa por hora del técnico.</li>
                    </ul>
                </div>

                <!-- Formulario de Adición -->
                <div class="card mt-3">
                    <div class="card-header">
                        Agregar Información del Técnico
                    </div>
                    <div class="card-body">

                        <!-- Mensaje de éxito con SweetAlert2 -->
                        <?php if(session('success')): ?>
                        <div id="success-message" class="d-none">
                            <span id="success-type">agregar</span>
                            <span id="module-name">Técnico</span>
                            <span id="redirect-url"><?php echo e(route('tecnicos.index')); ?></span>
                        </div>
                        <?php endif; ?>

                        <!-- Mensaje de error -->
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('tecnicos.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <!-- Nombre del Técnico -->
                            <div class="form-group">
                                <label for="nombre_tecnico">Nombre del Técnico</label>
                                <input type="text" name="nombre_tecnico" id="nombre_tecnico" class="form-control" value="<?php echo e(old('nombre_tecnico')); ?>" required>
                                <?php $__errorArgs = ['nombre_tecnico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- RUT -->
                            <div class="form-group">
                                <label for="rut_tecnico">RUT</label>
                                <input type="text" name="rut_tecnico" id="rut_tecnico" class="form-control" value="<?php echo e(old('rut_tecnico')); ?>" required>
                                <?php $__errorArgs = ['rut_tecnico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Teléfono -->
                            <div class="form-group">
                                <label for="telefono_tecnico">Teléfono</label>
                                <input type="text" name="telefono_tecnico" id="telefono_tecnico" class="form-control" value="<?php echo e(old('telefono_tecnico')); ?>" required>
                                <?php $__errorArgs = ['telefono_tecnico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Email -->
                            <div class="form-group">
                                <label for="email_tecnico">Email</label>
                                <input type="email" name="email_tecnico" id="email_tecnico" class="form-control" value="<?php echo e(old('email_tecnico')); ?>" required>
                                <?php $__errorArgs = ['email_tecnico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Precio por Hora -->
                            <div class="form-group">
                                <label for="precio_hora_tecnico">Precio por Hora</label>
                                <input type="number" step="0.01" name="precio_hora_tecnico" id="precio_hora_tecnico" class="form-control" value="<?php echo e(old('precio_hora_tecnico')); ?>" required>
                                <?php $__errorArgs = ['precio_hora_tecnico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <!-- Botón Guardar -->
                                <button type="submit" class="btn btn-primary" style="background-color: #cc0066; border-color: #cc0066;">
                                    <i class="fas fa-save"></i> Guardar
                                </button>

                                <!-- Botón Cancelar -->
                                <a href="<?php echo e(route('tecnicos.index')); ?>" class="btn btn-secondary" style="background-color: #cc0066; border-color: #cc0066;">
                                    <i class="fas fa-times-circle"></i> Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Incluye el archivo JavaScript -->
<script src="<?php echo e(asset('assets/js/mensajes/mensajes.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GITHUBV3\OTgithub2\SistemaOtv6 TESTEO\resources\views/tecnicos/agregar.blade.php ENDPATH**/ ?>